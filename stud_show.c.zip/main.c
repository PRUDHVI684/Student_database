#include<stdio.h>
#include "student.h"
#include<stdlib.h>
void Show_the_List(void){

        sll *temp;
        temp=head;
        if(temp==NULL){
                printf("list is empty\n");
                return;
        }
        else{
                        printf("------------------------------\n");
                        printf("Roll_no\tname\tpercent\n");
                        printf("------------------------------\n");
                while(temp){

                        printf("%d\t%s\t%.2f\n",temp->roll_number,temp->name,temp->percent);
                        temp=temp->next;
                }
        }
}
