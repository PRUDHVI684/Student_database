#include<stdio.h>
#include<stdlib.h>
#include<stdio_ext.h>
#include "student.h"

sll *head=NULL;
int count=0;

int main(int argv,char *argc[]){

        Load_records();
        printf("**** STUDENT RECORD MAMU ****\n");
        char choice;
        while(1){
                printf("a : Add New Record\n");
                printf("d : Delete a Record\n");
                printf("s : Show the List\n");
                printf("m : Modify a Record\n");
                printf("v : Save\n");
                printf("t : Sort the List\n");
                printf("e : Exit\n");
                printf("\n");
                printf("enter choice\n");
                __fpurge(stdin);
                scanf("%c",&choice);

        switch(choice){
                case 'a' : Add_new_record();
                           break;
                case 'd' : delete_records();
                           break;
                case 's' : Show_the_List();
                           break;
                //m : Modify a Record
                case 'v' : Save_records();
                           break;
                case 't' : Sort_list();
                           break;
                case 'e' : exit(0);

        }

}
}