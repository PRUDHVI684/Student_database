#include<stdio.h>
#include "student.h"

void Save_records(void){

        FILE *fp=fopen("student.dat","w");
        if(fp==NULL){
                printf("file not open\n");
                return;
        }
        else{
                sll *temp;
                temp=head;
                fprintf(fp,"-----------------------------\n");
                fprintf(fp,"Roll_no\t name\tpercent\n");
                fprintf(fp,"-----------------------------\n");
                while(temp){
                        fprintf(fp,"%d\t %s\t %.2f\n",temp->roll_number,temp->name,temp->percent);
                        temp=temp->next;
                }
        }
        printf("data saved successfully\n");
        fclose(fp);
}