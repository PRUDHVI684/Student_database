#include<stdio.h>
#include<stdlib.h>
#include "student.h"

void delete_records(void){

        char choice;
        printf("r.delete using roll number\n");
        printf("n.delete using name\n");
        printf("enter choice:");
        scanf(" %c",&choice);
        switch(choice)
                {
                        case 'r':delete_by_rollnum();
                                break;
                        //case 'n':delete_by_name();
                        //      break;
                        default:
                                printf("invalid input");
                }
}

void delete_by_rollnum(void){

        int roll_num;
        printf("enter roll_number\n");
        scanf("%d",&roll_num);
        sll *temp;
        temp=head;
        sll *prev;
        prev=NULL;

        if(temp==NULL){
                printf("No data to delete\n");
                return;
        }
        else{
                while(temp){

                        if(temp->roll_number==roll_num){

                                //for deleting first node

                                if(prev==NULL){
                                        head=temp->next;
                                }
                                else{
                                        prev->next=temp->next;

                                }
                                free(temp);
                                count--;
                                printf("data removed successfully\n");
                                return;
                        }
                        prev=temp;
                        temp=temp->next;
                }
                printf("roll_number not found\n");
        }
}
