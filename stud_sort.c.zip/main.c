
#include <stdio.h>
#include <string.h>
#include "student.h"

void Sort_list(void)
{
    char ch;
    sll *p, *q;
    int roll_number;
    float percent;
    char name[50];

    if (head == NULL)
    {
        printf("No records to sort\n");
        return;
    }

    printf("\nN/n : Sort by Name\n");
    printf("P/p : Sort by Percentage\n");
    printf("Enter Your Choice: ");
    scanf(" %c", &ch);

    for (p = head; p->next != NULL; p = p->next)
    {
        for (q = p->next; q != NULL; q = q->next)
        {
            int swap = 0;

            if (ch == 'N' || ch == 'n')
            {
                if (strcmp(p->name, q->name) > 0)
                    swap = 1;
            }
            else if (ch == 'P' || ch == 'p')
            {
                if (p->percent > q->percent)
                    swap = 1;
            }
            else
            {
                printf("Invalid choice\n");
                return;
            }

            if (swap)
            {
                // Swap roll numbers
                roll_number = p->roll_number;
                p->roll_number = q->roll_number;
                q->roll_number = roll_number;

                // Swap names
                strcpy(name, p->name);
                strcpy(p->name, q->name);
                strcpy(q->name, name);

                // Swap percentages
                percent = p->percent;
                p->percent = q->percent;
                q->percent = percent;
            }
        }
    }

   